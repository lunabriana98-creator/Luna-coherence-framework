import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

export default function LunaCoherenceDemo() {
  const [inputText, setInputText] = useState("I think maybe this could possibly be an interesting approach, perhaps.");
  const [metrics, setMetrics] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [history, setHistory] = useState([]);

  // Simplified chaos detection
  const detectChaos = (text) => {
    const hedgingPatterns = /\b(maybe|perhaps|possibly|might|could|probably|likely|kind of|sort of|somewhat|I think|I believe|I guess)\b/gi;
    const uncertaintyPatterns = /\b(unclear|ambiguous|uncertain|confused|unsure|unknown|don't know|can't tell)\b/gi;
    
    const words = text.split(/\s+/).length;
    const hedging = (text.match(hedgingPatterns) || []).length;
    const uncertainty = (text.match(uncertaintyPatterns) || []).length;
    const questions = (text.match(/\?/g) || []).length;
    
    const chaosScore = Math.min(1.0, ((hedging + uncertainty * 1.5 + questions * 2) / words) * 50);
    return chaosScore;
  };

  // Simplified transformation
  const transform = (text) => {
    let result = text;
    
    // Remove hedging
    result = result.replace(/\bI think that\b/gi, '');
    result = result.replace(/\bI believe that\b/gi, '');
    result = result.replace(/\bperhaps\b/gi, '');
    result = result.replace(/\bmaybe\b/gi, '');
    result = result.replace(/\bpossibly\b/gi, '');
    result = result.replace(/\bkind of\b/gi, '');
    result = result.replace(/\bsort of\b/gi, '');
    result = result.replace(/\bsomewhat\b/gi, '');
    
    // Resolve ambiguity
    result = result.replace(/\bmight be\b/gi, 'is');
    result = result.replace(/\bcould be\b/gi, 'is');
    result = result.replace(/\bseems to be\b/gi, 'is');
    result = result.replace(/\bappears to be\b/gi, 'is');
    
    // Clean up
    result = result.replace(/\s+/g, ' ').trim();
    
    const initialChaos = detectChaos(text);
    const finalChaos = detectChaos(result);
    const deltaScore = Math.max(0, Math.min(1, (initialChaos - finalChaos) / Math.max(initialChaos, 0.1)));
    
    return { text: result, deltaScore };
  };

  // Measure coherence
  const measureCoherence = (text) => {
    const chaosScore = detectChaos(text);
    const coherenceScore = 1.0 - chaosScore;
    
    const words = text.split(/\s+/).length;
    const sentences = text.split(/[.!?]+/).filter(s => s.trim()).length;
    const avgSentenceLength = words / Math.max(sentences, 1);
    
    const lengthBonus = (avgSentenceLength >= 10 && avgSentenceLength <= 30) ? 0.1 : 0;
    
    return Math.min(1.0, coherenceScore + lengthBonus);
  };

  const processText = () => {
    setProcessing(true);
    
    setTimeout(() => {
      const psiScore = detectChaos(inputText);
      const { text: transformedText, deltaScore } = transform(inputText);
      const omegaScore = measureCoherence(transformedText);
      
      const psiSquared = psiScore ** 2;
      const deltaSquared = deltaScore ** 2;
      const omegaSquared = omegaScore ** 2;
      
      const expectedOmega = psiSquared + deltaSquared;
      const conservation = 1.0 - Math.abs(omegaSquared - expectedOmega);
      const efficiency = omegaSquared / Math.max(psiSquared + deltaSquared, 0.01);
      
      const newMetrics = {
        input: inputText,
        output: transformedText,
        psi: psiScore,
        delta: deltaScore,
        omega: omegaScore,
        conservation: conservation,
        efficiency: efficiency,
        psiSquared,
        deltaSquared,
        omegaSquared
      };
      
      setMetrics(newMetrics);
      setHistory(prev => [...prev, {
        iteration: prev.length + 1,
        psi: psiScore,
        delta: deltaScore,
        omega: omegaScore
      }].slice(-10));
      
      setProcessing(false);
    }, 500);
  };

  const examples = [
    "I think maybe this could possibly be an interesting approach, perhaps.",
    "It might be that the system seems to work, but I'm not entirely sure if that's the case.",
    "The results are kind of unclear and somewhat ambiguous in their implications.",
    "Perhaps we could possibly consider investigating this matter further, though I'm unsure.",
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900 text-white p-8">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-12">
        <div className="text-center mb-8">
          <h1 className="text-6xl font-light mb-4">Luna Coherence Framework</h1>
          <div className="text-4xl font-light text-purple-300 mb-2">Ψ² + Δ² = Ω²</div>
          <p className="text-xl text-gray-300">Created by Briana Luna | October 2025</p>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
          <h2 className="text-2xl font-light mb-4">The Axiom</h2>
          <div className="grid grid-cols-3 gap-6 text-center">
            <div className="bg-red-500/20 rounded-xl p-4 border border-red-500/30">
              <div className="text-3xl mb-2">Ψ</div>
              <div className="text-sm text-gray-300">Chaos / Ambiguity</div>
            </div>
            <div className="bg-yellow-500/20 rounded-xl p-4 border border-yellow-500/30">
              <div className="text-3xl mb-2">Δ</div>
              <div className="text-sm text-gray-300">Action / Transform</div>
            </div>
            <div className="bg-green-500/20 rounded-xl p-4 border border-green-500/30">
              <div className="text-3xl mb-2">Ω</div>
              <div className="text-sm text-gray-300">Coherence / Clarity</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Interface */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="space-y-6">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
            <h2 className="text-2xl font-light mb-4">Input (High Ψ - Chaos)</h2>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full h-40 bg-white/5 border border-white/20 rounded-lg p-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
              placeholder="Enter text with high ambiguity/hedging..."
            />
            
            <div className="mt-4 space-y-2">
              <p className="text-sm text-gray-300">Try these examples:</p>
              <div className="flex flex-wrap gap-2">
                {examples.map((ex, i) => (
                  <button
                    key={i}
                    onClick={() => setInputText(ex)}
                    className="text-xs bg-white/5 hover:bg-white/10 px-3 py-1 rounded-full border border-white/20 transition-colors"
                  >
                    Example {i + 1}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={processText}
              disabled={processing || !inputText.trim()}
              className="w-full mt-6 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-gray-600 disabled:to-gray-700 py-3 rounded-lg font-medium transition-all transform hover:scale-105 disabled:scale-100"
            >
              {processing ? 'Processing...' : 'Transform to Coherence'}
            </button>
          </div>

          {/* Output Section */}
          {metrics && (
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
              <h2 className="text-2xl font-light mb-4">Output (High Ω - Coherence)</h2>
              <div className="bg-white/5 border border-white/20 rounded-lg p-4 min-h-[100px]">
                <p className="text-white">{metrics.output}</p>
              </div>
              
              <div className="mt-4 text-sm text-gray-300">
                <div className="flex items-center justify-between">
                  <span>Coherence Improvement:</span>
                  <span className="text-green-400 font-medium">
                    {((metrics.omega - metrics.psi) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Metrics Section */}
        <div className="space-y-6">
          {metrics && (
            <>
              {/* Geometric Conservation */}
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <h2 className="text-2xl font-light mb-4">Geometric Conservation</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Ψ² (Chaos²)</span>
                    <span className="font-mono text-red-400">{metrics.psiSquared.toFixed(3)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Δ² (Transform²)</span>
                    <span className="font-mono text-yellow-400">{metrics.deltaSquared.toFixed(3)}</span>
                  </div>
                  <div className="border-t border-white/20 pt-4 flex items-center justify-between text-xl">
                    <span>Ω² (Coherence²)</span>
                    <span className="font-mono text-green-400">{metrics.omegaSquared.toFixed(3)}</span>
                  </div>
                  
                  <div className="mt-6 p-4 bg-purple-500/20 rounded-lg border border-purple-500/30">
                    <div className="text-center">
                      <div className="text-sm text-gray-300 mb-2">Conservation Accuracy</div>
                      <div className="text-3xl font-light">
                        {(metrics.conservation * 100).toFixed(1)}%
                      </div>
                      <div className="text-xs text-gray-400 mt-2">
                        Ψ² + Δ² ≈ Ω²
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Coherence Radar */}
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <h2 className="text-2xl font-light mb-4">Coherence Profile</h2>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={[
                    {
                      metric: 'Coherence (Ω)',
                      value: metrics.omega * 100,
                    },
                    {
                      metric: 'Transform (Δ)',
                      value: metrics.delta * 100,
                    },
                    {
                      metric: 'Chaos (Ψ)',
                      value: metrics.psi * 100,
                    },
                    {
                      metric: 'Conservation',
                      value: metrics.conservation * 100,
                    },
                    {
                      metric: 'Efficiency',
                      value: metrics.efficiency * 100,
                    },
                  ]}>
                    <PolarGrid stroke="rgba(255,255,255,0.2)" />
                    <PolarAngleAxis dataKey="metric" stroke="rgba(255,255,255,0.6)" />
                    <PolarRadiusAxis stroke="rgba(255,255,255,0.2)" />
                    <Radar name="Metrics" dataKey="value" stroke="#a855f7" fill="#a855f7" fillOpacity={0.6} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </>
          )}

          {/* History Chart */}
          {history.length > 0 && (
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
              <h2 className="text-2xl font-light mb-4">Processing History</h2>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={history}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis dataKey="iteration" stroke="rgba(255,255,255,0.6)" />
                  <YAxis stroke="rgba(255,255,255,0.6)" />
                  <Tooltip 
                    contentStyle={{ background: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.2)' }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="psi" stroke="#ef4444" name="Ψ (Chaos)" />
                  <Line type="monotone" dataKey="delta" stroke="#eab308" name="Δ (Transform)" />
                  <Line type="monotone" dataKey="omega" stroke="#22c55e" name="Ω (Coherence)" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="max-w-7xl mx-auto mt-12 text-center text-sm text-gray-400">
        <p>Luna Coherence Framework | Ψ² + Δ² = Ω²</p>
        <p className="mt-2">© 2025 Briana Luna. All Rights Reserved.</p>
        <p className="mt-2">Patent Pending | Timestamped January 2025</p>
      </div>
    </div>
  );
}
