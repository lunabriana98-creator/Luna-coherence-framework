"""
Basic Usage Examples for Luna Coherence Framework

This script demonstrates common use cases for the framework.
"""

from luna_coherence_framework import (
    GeometricProcessor,
    LunaAdoptionProtocol,
    CoherenceMetrics
)

def example_basic_processing():
    """Example 1: Basic text processing"""
    print("=" * 60)
    print("EXAMPLE 1: Basic Processing")
    print("=" * 60)
    
    processor = GeometricProcessor()
    
    # Text with high chaos (ambiguity, hedging)
    input_text = "I think maybe this could possibly be an interesting approach, perhaps."
    
    # Process through framework
    output, metrics = processor.process(input_text)
    
    print(f"\nInput:  {input_text}")
    print(f"Output: {output}")
    print(f"\nΨ (Chaos):    {metrics.psi_score:.3f}")
    print(f"Δ (Transform): {metrics.delta_score:.3f}")
    print(f"Ω (Coherence): {metrics.omega_score:.3f}")
    print(f"\nImprovement: {((metrics.omega_score - metrics.psi_score) * 100):.1f}%")

def example_iterative_optimization():
    """Example 2: Iterative optimization for complex text"""
    print("\n" + "=" * 60)
    print("EXAMPLE 2: Iterative Optimization")
    print("=" * 60)
    
    processor = GeometricProcessor()
    
    complex_text = """
    I'm not entirely sure, but it seems like maybe there could 
    possibly be some kind of relationship between these variables, 
    though I can't say for certain.
    """
    
    print(f"\nOriginal: {complex_text.strip()}")
    
    # Apply iterative optimization
    final_output, history = processor.iterative_optimize(complex_text, max_iterations=5)
    
    print(f"\nOptimized: {final_output.strip()}")
    print(f"\nIterations: {len(history)}")
    
    print("\nCoherence progression:")
    for i, metrics in enumerate(history, 1):
        print(f"  Iteration {i}: Ω = {metrics.omega_score:.3f}")

def example_geometric_validation():
    """Example 3: Geometric conservation validation"""
    print("\n" + "=" * 60)
    print("EXAMPLE 3: Geometric Conservation (Ψ² + Δ² = Ω²)")
    print("=" * 60)
    
    processor = GeometricProcessor()
    
    test_text = "It might be that this approach could work, but I'm unsure."
    output, metrics = processor.process(test_text)
    
    psi_squared = metrics.psi_score ** 2
    delta_squared = metrics.delta_score ** 2
    omega_squared = metrics.omega_score ** 2
    
    print(f"\nΨ² = {psi_squared:.4f}")
    print(f"Δ² = {delta_squared:.4f}")
    print(f"Sum = {psi_squared + delta_squared:.4f}")
    print(f"\nΩ² = {omega_squared:.4f}")
    print(f"\nConservation accuracy: {metrics.geometric_conservation:.1%}")
    
    if metrics.geometric_conservation > 0.9:
        print("✓ Geometric conservation validated!")
    else:
        print("⚠ Conservation error detected")

def example_ai_adoption():
    """Example 4: AI system framework adoption"""
    print("\n" + "=" * 60)
    print("EXAMPLE 4: AI Framework Adoption")
    print("=" * 60)
    
    protocol = LunaAdoptionProtocol()
    
    test_inputs = [
        "Perhaps this might work, I'm not sure.",
        "It could be interesting, maybe.",
        "I think that seems like it might help."
    ]
    
    print("\nTesting with adoption_level = 0.0 (no framework):")
    protocol.adopt_framework(0.0)
    for text in test_inputs[:1]:
        output, metrics = protocol.process_with_framework(text, text)
        print(f"  Coherence: {metrics.omega_score:.3f}")
    
    print("\nTesting with adoption_level = 1.0 (full framework):")
    protocol.adopt_framework(1.0)
    for text in test_inputs[:1]:
        output, metrics = protocol.process_with_framework(text, text)
        print(f"  Coherence: {metrics.omega_score:.3f}")
        print(f"  Output: {output}")

def example_batch_processing():
    """Example 5: Batch processing multiple texts"""
    print("\n" + "=" * 60)
    print("EXAMPLE 5: Batch Processing")
    print("=" * 60)
    
    processor = GeometricProcessor()
    
    texts = [
        "I think maybe this is good.",
        "Perhaps it could work, possibly.",
        "It seems like it might be useful, I guess.",
    ]
    
    results = []
    for text in texts:
        output, metrics = processor.process(text)
        results.append({
            'input': text,
            'output': output,
            'improvement': metrics.omega_score - metrics.psi_score
        })
    
    print("\nProcessing results:")
    for i, result in enumerate(results, 1):
        print(f"\n{i}. Input:  {result['input']}")
        print(f"   Output: {result['output']}")
        print(f"   Improvement: {result['improvement']*100:.1f}%")
    
    avg_improvement = sum(r['improvement'] for r in results) / len(results)
    print(f"\nAverage improvement: {avg_improvement*100:.1f}%")

if __name__ == "__main__":
    print("\n")
    print("╔" + "=" * 58 + "╗")
    print("║" + " " * 58 + "║")
    print("║" + "  LUNA COHERENCE FRAMEWORK - USAGE EXAMPLES  ".center(58) + "║")
    print("║" + "  Ψ² + Δ² = Ω²  ".center(58) + "║")
    print("║" + " " * 58 + "║")
    print("╚" + "=" * 58 + "╝")
    print("\n")
    
    # Run all examples
    example_basic_processing()
    example_iterative_optimization()
    example_geometric_validation()
    example_ai_adoption()
    example_batch_processing()
    
    print("\n" + "=" * 60)
    print("Examples complete!")
    print("=" * 60)
    print("\nFor more information, see:")
    print("  - README.md for overview")
    print("  - LUNA_FRAMEWORK_DOCUMENTATION.md for technical details")
    print("  - luna_coherence_framework.py for full implementation")
    print("\n")
